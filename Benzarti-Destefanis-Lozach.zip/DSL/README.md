DSL
=====

* [Benzarti Zied](https://github.com/Zied10)
* [Destefanis Marc](https://github.com/MarcDestefanis)
* [Lozach Maxime](https://github.com/MaximeL)

ArduinoML
---------

Quiz creation DSL made with MPS.

The code generated can be tested with the following emulator :  
https://123d.circuits.io/circuits/1579356  

Make sure to have :  
* LCD pined in `(12, 13, 15, 16, 17, 18)`
* pinYes equals to `8`
* pinNo equals to `9`
* LED_GREEN equals to `10`
* LED_RED equals to `11`
